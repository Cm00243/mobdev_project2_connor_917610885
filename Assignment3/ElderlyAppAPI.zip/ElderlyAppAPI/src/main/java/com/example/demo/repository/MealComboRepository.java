package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.MealCombo;
import com.example.demo.model.MealCombo.MealType;

import java.util.List;

@Repository
public interface MealComboRepository extends JpaRepository<MealCombo, Long> {
    // Custom query method to find meal combos by meal type
	List<MealCombo> findByMealType(MealCombo.MealType mealType);
}