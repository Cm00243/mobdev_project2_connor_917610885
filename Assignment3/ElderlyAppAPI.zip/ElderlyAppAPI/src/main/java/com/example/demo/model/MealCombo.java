package com.example.demo.model;

import java.util.List;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class MealCombo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Unique identifier for the combo

    @Enumerated(EnumType.STRING)  // Store as String in the database
    private MealType mealType;    // Type of meal (BREAKFAST, LUNCH, DINNER)

    @ElementCollection  // Indicates a collection of basic or embeddable types
    private List<String> comboItems; // List of items in the combo

    // Default constructor
    public MealCombo() {}

    // Parameterized constructor
    public MealCombo(Long id, MealType mealType, List<String> comboItems) {
        this.id = id;
        this.mealType = mealType;
        this.comboItems = comboItems;
    }

    // Getter and setter for id
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    // Getter and setter for mealType
    public MealType getMealType() {
        return mealType;
    }

    public void setMealType(MealType mealType) {
        this.mealType = mealType;
    }

    // Getter and setter for comboItems
    public List<String> getComboItems() {
        return comboItems;
    }

    public void setComboItems(List<String> comboItems) {
        this.comboItems = comboItems;
    }

    // Enum for meal types
    public enum MealType {
        BREAKFAST,
        LUNCH,
        DINNER
    }
}
