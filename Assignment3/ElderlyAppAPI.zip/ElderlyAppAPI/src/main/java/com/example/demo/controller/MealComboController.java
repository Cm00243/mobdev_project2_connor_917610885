package com.example.demo.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.MealCombo;
import com.example.demo.service.MealComboService;

import java.util.List;

@RestController
@RequestMapping("/api/v1/meal") // Base URL for the controller
public class MealComboController {

    private final MealComboService mealComboService;

    public MealComboController(MealComboService mealComboService) {
        this.mealComboService = mealComboService;
    }

    // Get all meal combos
    @GetMapping
    public ResponseEntity<List<MealCombo>> getAllMealCombos() {
        List<MealCombo> mealCombos = mealComboService.findAll();
        return new ResponseEntity<>(mealCombos, HttpStatus.OK);
    }

    // Get meal combos by meal type
    @GetMapping("/{mealType}")
    public ResponseEntity<List<MealCombo>> getCombosByMealType(@PathVariable String mealType) {
        List<MealCombo> mealCombos = mealComboService.getCombosByMealType(mealType);
        return new ResponseEntity<>(mealCombos, HttpStatus.OK);
    }

    // Add a new meal combo
    @PostMapping
    public ResponseEntity<MealCombo> createMealCombo(@RequestBody MealCombo mealCombo) {
        MealCombo createdMealCombo = mealComboService.save(mealCombo);
        return new ResponseEntity<>(createdMealCombo, HttpStatus.CREATED);
    }

    // Update an existing meal combo
    @PutMapping("/{id}")
    public ResponseEntity<MealCombo> updateMealCombo(@PathVariable Long id, @RequestBody MealCombo mealCombo) {
        MealCombo updatedMealCombo = mealComboService.update(id, mealCombo);
        return new ResponseEntity<>(updatedMealCombo, HttpStatus.OK);
    }

    // Delete a meal combo
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMealCombo(@PathVariable Long id) {
        mealComboService.delete(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}