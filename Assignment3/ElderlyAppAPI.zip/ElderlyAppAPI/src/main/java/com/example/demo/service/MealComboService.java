package com.example.demo.service;

import org.springframework.stereotype.Service;
import com.example.demo.model.MealCombo;
import com.example.demo.repository.MealComboRepository;

import java.util.List;

@Service
public class MealComboService {
    private final MealComboRepository mealComboRepository;

    public MealComboService(MealComboRepository mealComboRepository) {
        this.mealComboRepository = mealComboRepository;
    }

    public List<MealCombo> findAll() {
        return mealComboRepository.findAll();
    }

    public List<MealCombo> getCombosByMealType(String mealType) {
        try {
            MealCombo.MealType type = MealCombo.MealType.valueOf(mealType.toUpperCase());
            return mealComboRepository.findByMealType(type);
        } catch (IllegalArgumentException e) {
            // Handle the case where the meal type is invalid
            // For example, return an empty list or throw an exception
            return List.of(); // Return an empty list for invalid types
        }
    }

    public MealCombo save(MealCombo mealCombo) {
        return mealComboRepository.save(mealCombo);
    }

    public MealCombo update(Long id, MealCombo mealCombo) {
        mealCombo.setId(id); // Make sure to set the ID for the update
        return mealComboRepository.save(mealCombo);
    }

    public void delete(Long id) {
        mealComboRepository.deleteById(id);
    }
}