package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.example.demo.model.MealCombo;

public class MealComboTest {

    private MealCombo breakfastCombo;

    @BeforeEach
    public void setUp() {
        // Initialize a MealCombo instance before each test
        List<String> breakfastItems = Arrays.asList("sausage", "grit", "tea", "toast");
        breakfastCombo = new MealCombo(1L, MealCombo.MealType.BREAKFAST, breakfastItems);
    }

    @Test
    public void testMealComboCreation() {
        // Check that the MealCombo instance is not null
        assertNotNull(breakfastCombo);
        
        // Verify the id, mealType, and comboItems are set correctly
        assertEquals(1L, breakfastCombo.getId());
        assertEquals(MealCombo.MealType.BREAKFAST, breakfastCombo.getMealType());
        assertEquals(4, breakfastCombo.getComboItems().size());
    }

    @Test
    public void testSetId() {
        // Test setting a new ID
        breakfastCombo.setId(2L);
        assertEquals(2L, breakfastCombo.getId());
    }

    @Test
    public void testSetMealType() {
        // Test changing the meal type to LUNCH
        breakfastCombo.setMealType(MealCombo.MealType.LUNCH);
        assertEquals(MealCombo.MealType.LUNCH, breakfastCombo.getMealType());
    }

    @Test
    public void testSetComboItems() {
        // Test changing the combo items
        List<String> newItems = Arrays.asList("pancake", "bacon", "coffee");
        breakfastCombo.setComboItems(newItems);
        assertEquals(newItems, breakfastCombo.getComboItems());
    }
}
